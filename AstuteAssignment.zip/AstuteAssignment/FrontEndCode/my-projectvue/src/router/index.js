import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import AjaxComponent from '@/components/AjaxExampleComponent'
import SearchByLabel from '@/components/SearchByLabelComponent'
import BootstrapVue from 'bootstrap-vue/dist/bootstrap-vue.esm'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import 'bootstrap/dist/css/bootstrap.css'

Vue.use(Router)
let originalVueComponent = Vue.component
Vue.component = function (name, definition) {
  if (name === 'bFormCheckboxGroup' || name === 'bCheckboxGroup' ||
    name === 'bCheckGroup' || name === 'bFormRadioGroup') {
    definition.components = {bFormCheckbox: definition.components[0]}
  }
  originalVueComponent.apply(this, [name, definition])
}
Vue.use(BootstrapVue)
Vue.component = originalVueComponent
export default new Router({
  routes: [
    {
      path: '/example1',
      name: 'Hello',
      component: HelloWorld
    },
    {
      path: '/example2',
      name: 'AjaxExample',
      component: AjaxComponent
    },
    {
      path: '/example3',
      name: 'SearchByLabel',
      component: SearchByLabel
    }
  ]
})
