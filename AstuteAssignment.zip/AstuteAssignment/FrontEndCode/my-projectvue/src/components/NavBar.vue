<template>
  <b-navbar toggleable type="inverse" variant="primary" toggle-breakpoint="md">
    <b-navbar-brand href="#">The Project: Lost in Translation</b-navbar-brand>
  </b-navbar>
</template>
<script>
  export default{
    name: 'NavBar',
    data () {
      return {
      }
    }
  }
</script>
<style scoped>
  h1, h2 {
    font-weight: normal;
  }

  ul {
    list-style-type: none;
    padding: 0;
  }

  li {
    display: inline-block;
    margin: 0 10px;
  }

  a {
    color: white;
    text-align: center;
    margin: auto;
  }
  .success{
    background-color: #007bff;
  }

</style>
