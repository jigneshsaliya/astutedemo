<template>
  <div class="hello">
    <nav-bar></nav-bar>
    <div class="container">
      <div class="row" style="margin-top:10px;">
        <table class="table table-striped">
          <thead>
          <tr class="alert alert-success">
            <th>Ex# 2. Search lable by using key name(But using Ajax call)</th>
            <button type="button" class="btn btn-warning" v-on:click="navigateToExample('example1')">Ex1</button>
            <button type="button" class="btn btn-warning" v-on:click="navigateToExample('example2')">Ex2</button>
            <button type="button" class="btn btn-warning" v-on:click="navigateToExample('example3')">Ex3</button>
          </tr>
          </thead>
        </table>
      </div>
      <div class="row">
        <div class="col-9">
          <h5></h5>
          <input class="form-control" v-model="searchTextAjax"
                        type="text"
                        placeholder="Enter key name"
                        v-on:keyup.enter="onEnterClick($event)"
          />
        </div>
        <div class="col-1">
          <h5></h5>
          <b-button size="" variant="primary" v-on:click="makeSearch()">
            Search
          </b-button>
        </div>
      </div>
      <div class="row" style="margin-top:10px;" v-if="showFlag">
        <table class="table table-striped">
          <thead>
          <tr class="success">
            <th>Search Results</th>
          </tr>
          </thead>
          <tbody>
          <tr>
            <td>{{searchResult}}</td>
          </tr>
          </tbody>
        </table>
      </div>
      <div class="row" style="margin-top:10px;" v-else>
        <table class="table table-striped">
          <thead>
          <tr class="success">
            <th>Search Results</th>
          </tr>
          </thead>
          <tbody>
          <tr class="alert alert-danger">
            <td class="alert alert-danger">No Records found</td>
          </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>
<script>
  import NavBar from './NavBar.vue'
  import axios from 'axios'
  import config from '../app.config'
  export default {
    name: 'AjaxComponent',
    components: {
      'navBar': NavBar
    },
    data () {
      return {
        searchTextAjax: '',
        searchResult: '',
        viewResultString: '',
        showFlag: false
      }
    },
    methods: {
      onEnterClick: function (event) {
        var self = this
        if (event.keyCode === 13) {
          self.makeSearch()
        }
        event.stopPropagation()
      },
      navigateToExample: function (lable) {
        if (lable === 'example1') {
          this.$router.push('/example1')
        } else if (lable === 'example2') {
          this.$router.push('/example2')
        } else {
          this.$router.push('/example3')
        }
      },
      makeSearch: function () {
        var uri = config.baseUrl + 'getlanglable?key=' + this.searchTextAjax
        axios.get(uri)
          .then(response => {
            if (response.data.statusCode === '200') {
              this.showFlag = true
              this.searchResult = response.data.message
            }
          })
          .catch(e => {
            console.log('test1')
            this.showFlag = false
          })
      }
    },
    created () {
    }
  }
</script>
<style scoped>

  th,td{
    text-align: left;
  }
  .success{
    background-color: #007bff;
  }
  table{
    margin-left: 15px;
    width: 82%;
  }
  .btn-warning{
    margin: 5px;
  }
</style>


