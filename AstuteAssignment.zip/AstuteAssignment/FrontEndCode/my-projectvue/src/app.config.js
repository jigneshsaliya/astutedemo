/**
 * Created by jigne on 11/1/2017.
 */
export default {
  baseUrl: 'http://localhost:8080/'
}
