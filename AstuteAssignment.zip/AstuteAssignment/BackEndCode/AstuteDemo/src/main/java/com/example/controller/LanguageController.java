package com.example.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Constant;
import com.example.model.Response;
import com.example.service.LanguageServiceInterFace;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Jignesh Saliya
 * @version 1.0.0
 * @Description - Below is the REST controller for Astute demo application
 */

@RestController
public class LanguageController {
	
	@Autowired
	LanguageServiceInterFace languageService;
	
	/**
	 * @Description : Below methos will return language JSON file on uri call
	 * @param null
	 * @return Map<String, Object>
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 * @uri : http://localhost:8080/getlangjson
	 */
	@RequestMapping("/getlangjson")
	public  Map<String, Object> getJSONDate() throws JsonParseException, JsonMappingException, IOException{
		ObjectMapper jsonMapper = new ObjectMapper();
		ClassLoader classLoader = getClass().getClassLoader();
		Map<String,Object> map = jsonMapper.readValue(new File(classLoader.getResource("translate.json").getFile()), HashMap.class);
		return map;
	}
	
	/**
	 * @Description : Below method will return matched language lable when passed Key value will get match
	 * @param key
	 * @param request
	 * @param response
	 * @return ResponseEntity<?>
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 * @uri : http://localhost:8080/getlable?key=login.user
	 */
	
	@RequestMapping("/getlanglable")
	public ResponseEntity<?> getJson(@RequestParam(value = "key", required = true) String key,
			HttpServletRequest request, HttpServletResponse response) throws JsonParseException, JsonMappingException, IOException {
		Response responseEntiry = null;
		//Logic for getting value based of key
		responseEntiry = languageService.getStringLable(key);
		if(responseEntiry.getStatusCode()==Constant.HTTP_NOT_FOUND) {
			return new ResponseEntity<>(responseEntiry, HttpStatus.NOT_FOUND);
		}else {
			return new ResponseEntity<>(responseEntiry, HttpStatus.OK);
		}
	}
	
	
	/**
	 * @Description : Below method will return matched key name based on supplied language lable
	 * @param key
	 * @param request
	 * @param response
	 * @return ResponseEntity<?>
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 * @uri : http://localhost:8080/findKey?key=This page is available in variery of languages
	 * 
	 */
	@RequestMapping("/getlangKey")
	public ResponseEntity<?> getKeyList(@RequestParam(value = "key", required = true) String key,
			HttpServletRequest request, HttpServletResponse response) throws JsonParseException, JsonMappingException, IOException{
		Response responseEntiry = null;
		responseEntiry = languageService.getKeyLableMap(key);
		if(responseEntiry.getStatusCode()==Constant.HTTP_NOT_FOUND) {
			return new ResponseEntity<>(responseEntiry, HttpStatus.NOT_FOUND);
		}else {
			return new ResponseEntity<>(responseEntiry, HttpStatus.OK);
		}
	}
}
