package com.example.model;

/**
 * @author Jignesh Saliya
 * @version 1.0.0
 * @Description: This is a constant file and this will contain all string value
 *
 */
public class Constant {
	
	public static final String HTTP_NOT_FOUND ="404";
	public static final String HTTP_FOUND="200";
	
	public static final String NOT_FOUND_STRING="Not Found";
	public static final String NOT_FOUND_MESSAGE = "Requested String Lable Not Found";
	
	public static final String FOUND_OK = "Ok";
}
