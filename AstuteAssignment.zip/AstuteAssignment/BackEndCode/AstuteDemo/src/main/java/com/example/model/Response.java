package com.example.model;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
public class Response {
	private String statusCode;
	private String statusMessage;
	private String message;
	private ArrayList<String> matchedKey;
	
	public ArrayList<String> getMatchedKey() {
		return matchedKey;
	}
	public void setMatchedKey(ArrayList<String> matchedKey) {
		this.matchedKey = matchedKey;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
