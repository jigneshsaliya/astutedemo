package com.example.service;

import java.util.LinkedList;
import java.util.Map;

import com.example.model.Response;

/**
 * @author Jignesh Saliya
 * @Version 1.0.0
 * @Description: This is an interface of Language service
 *
 */


public interface  LanguageServiceInterFace {
	
	/**
	 * @param key
	 * @return Response
	 * @Description : This is the service which will return key of matched lable
	 */
	public Response getStringLable(String key);
	
	/**
	 * @param searchKey
	 * @return Response
	 * @Description : This is the service which will return lable of matched key
	 */
	public Response getKeyLableMap(String searchKey);
	
	/**
	 * @param map
	 * @param out
	 * @param list
	 * @return Map<String,String>
	 * @Description : This is the service interface which will return map of Key and value pair
	 */
	public Map<String,String> getParseLanguageJson(Map<String, Object> map , Map<String,String> out,LinkedList<String> list);
}
