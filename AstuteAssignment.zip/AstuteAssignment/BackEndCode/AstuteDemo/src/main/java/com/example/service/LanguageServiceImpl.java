package com.example.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.model.Constant;
import com.example.model.Response;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Jignesh Saliya
 * @version 1.0.0
 * @Description: This is the serviceImplementation of Language service interface
 *
 */
@Service
public class LanguageServiceImpl implements LanguageServiceInterFace{
	
	@Override
	public Response getStringLable(String key) {
		Response responseEntiry = new Response();
		String finalValue = "";
		
		ClassLoader classLoader = getClass().getClassLoader();
		ObjectMapper jsonMapper = new ObjectMapper();
		Map<String, Object> map = null;
		try {
			map = jsonMapper.readValue(new File(classLoader.getResource("translate.json").getFile()), HashMap.class);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		LanguageServiceImpl languageServiceImpl = new LanguageServiceImpl();
		Map<String,String> keyLableMap = new HashMap<String, String>();
		LinkedList<String> list = new LinkedList<>();
		keyLableMap = languageServiceImpl.getParseLanguageJson(map,keyLableMap,list);
		
		finalValue = keyLableMap.get(key);
		
		if(finalValue == "" || finalValue == null) {
			responseEntiry.setStatusCode(Constant.HTTP_NOT_FOUND);			
			responseEntiry.setStatusMessage(Constant.NOT_FOUND_STRING);
			responseEntiry.setMessage(Constant.NOT_FOUND_MESSAGE);
		}else {
			responseEntiry.setStatusCode(Constant.HTTP_FOUND);
			responseEntiry.setStatusMessage(Constant.FOUND_OK);
			responseEntiry.setMessage(finalValue);
		}
		return responseEntiry;
	}

	@Override
	public Response getKeyLableMap(String searchKey) {
		Response responseEntiry = new Response();
		ClassLoader classLoader = getClass().getClassLoader();
		ObjectMapper jsonMapper = new ObjectMapper();
		Map<String, Object> map = null;
		try {
			map = jsonMapper.readValue(new File(classLoader.getResource("translate.json").getFile()), HashMap.class);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		LanguageServiceImpl languageServiceImpl = new LanguageServiceImpl();
		Map<String,String> keyLableMap = new HashMap<String, String>();
		LinkedList<String> list = new LinkedList<>();
		keyLableMap = languageServiceImpl.getParseLanguageJson(map,keyLableMap,list);
		
		Set<String> keySet = keyLableMap.keySet();
		Iterator<String> keyIterator = keySet.iterator();
		ArrayList<String> matchKeyList = new ArrayList<>();
		while (keyIterator.hasNext()) {
			String key = keyIterator.next();
			String value = keyLableMap.get(key);
			if(value.equalsIgnoreCase(searchKey) && searchKey!= null) {
				matchKeyList.add(key);
			}
		}
		
		if(matchKeyList.isEmpty()) {
			responseEntiry.setStatusCode(Constant.HTTP_NOT_FOUND);			
			responseEntiry.setStatusMessage(Constant.NOT_FOUND_STRING);
			responseEntiry.setMessage(Constant.NOT_FOUND_MESSAGE);
		}else {
			responseEntiry.setStatusCode(Constant.HTTP_FOUND);
			responseEntiry.setStatusMessage(Constant.FOUND_OK);
			responseEntiry.setMatchedKey(matchKeyList);
		}
		return responseEntiry;
	}

	@Override
	public Map<String, String> getParseLanguageJson(Map<String, Object> map, Map<String, String> out,
			LinkedList<String> list) {
		ObjectMapper oMapper = new ObjectMapper();
		Set<String> it =  map.keySet();
		Iterator<String> keySet = it.iterator();
		while (keySet.hasNext()) {
			String key = keySet.next();
			String val = null;
			try {
				list.add(key);
				Object mapObject = map.get(key); 
				getParseLanguageJson(oMapper.convertValue(mapObject, HashMap.class), out,list);
			}catch(Exception e){
				val = (String) map.get(key);
			}
			if(key!=null && val!= null) {
				StringBuffer keyLable = new StringBuffer();
				for (int i = 0; i < list.size(); i++) {
					if(i == list.size()-1) {
						keyLable.append(list.get(i));
					}else {
						keyLable.append(list.get(i)+".");
					}
		        }
				list.removeLast();
				out.put(new String(keyLable), val);
			}
		}
		try {
			list.removeLast();
		}catch(Exception e) {
			
		}
		return out;
	}

}
