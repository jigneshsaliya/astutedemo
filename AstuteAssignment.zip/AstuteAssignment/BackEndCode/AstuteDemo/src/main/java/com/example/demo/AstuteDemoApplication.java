package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author Jignesh Saliya
 * @version 1.0.0
 * @Description : Spring boot class
 *
 */
@Configuration
@EnableAutoConfiguration
@ComponentScan({"com.example.controller","com.example.service","com.example.demo"})
public class AstuteDemoApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(AstuteDemoApplication.class, args);
	}
}
